package com.cg.deliveringproducts.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="capstoreinventory")
@XmlRootElement
public class Inventory {
	
	@Id
	@Column(name="pid")
	private Integer pid;
	
	@Column(name="name")
	private String name;
	
	public Inventory() {
		// TODO Auto-generated constructor stub
	}
	
	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Inventory [pid=" + pid + ", name=" + name + "]";
	}


	
}
