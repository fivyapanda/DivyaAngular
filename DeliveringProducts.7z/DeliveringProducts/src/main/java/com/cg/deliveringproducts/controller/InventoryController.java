package com.cg.deliveringproducts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.deliveringproducts.entities.Inventory;
import com.cg.deliveringproducts.services.IInventory;

@RestController
@RequestMapping("/inventory")
public class InventoryController {
 
	@Autowired private IInventory service;
	
	@GetMapping(value="/getbyid/{id}")
	 public Inventory findById(@PathVariable("id") Integer id) {
	 return service.findById(id);
	 }
	
	@PutMapping(value="/updateinventory",consumes={"application/json","application/xml"})
	 public ResponseEntity<String> update(@RequestBody Inventory i) {
	 service.updateInventory(i);
	 return new ResponseEntity<String>("Record updated! \n",HttpStatus.OK);
	 }
	
	@DeleteMapping(value="/deleteproduct")
	 public ResponseEntity<String> delete(@RequestParam("id") Integer id) {
	 service.deleteById(id);
	 return new ResponseEntity<String>("Record deleted",HttpStatus.OK);
	 }
}
