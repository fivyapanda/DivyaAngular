package com.cg.deliveringproducts.services;

import com.cg.deliveringproducts.entities.Inventory;


public interface IInventory {
	public Inventory findById(int id);
	public void deleteById(int id);
	public void updateInventory(Inventory i);


}
