package com.cg.deliveringproducts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveringProductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveringProductsApplication.class, args);
	}

}
