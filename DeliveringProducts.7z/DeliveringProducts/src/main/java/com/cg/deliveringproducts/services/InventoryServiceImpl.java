package com.cg.deliveringproducts.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.deliveringproducts.dao.InventoryDao;
import com.cg.deliveringproducts.entities.Inventory;
import com.cg.deliveringproducts.exceptions.ApplicationException;
@Service
public class InventoryServiceImpl implements IInventory {

	@Autowired private InventoryDao dao;

	@Override
	public Inventory findById(int id) {
		// TODO Auto-generated method stub
		 System.out.println("Finding product: "+id);
		 Optional<Inventory> temp = dao.findById(id);
		 if(!temp.isPresent()) {
		 throw new ApplicationException("Product not found "+id);
		 }
		 return temp.get();
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		System.out.println("Deleting product: "+id);
		 if(!dao.existsById(id)) {
		 throw new ApplicationException("No record to delete");
		 }
		 dao.deleteById(id);
	} 
	
	@Override
	public void updateInventory(Inventory i) {
		// TODO Auto-generated method stub
		 System.out.println("Updating Inventory: "+i.getPid());
		 if(! dao.existsById(i.getPid())) {
		 throw new ApplicationException("Record did not exists!");
		 }
		 dao.save(i);
	}

	

}
