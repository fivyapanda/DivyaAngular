import { Component, OnInit,Input } from '@angular/core';
import { Employee} from './employee';
import { pipeBind1 } from '../../../node_modules/@angular/core/src/render3';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  
@Input('name') title: string;
doj = new Date;
  eid : number;
  ename : string;
  esal : number;
imageUrl="../assets/thT38NOT5Z.jpg";

employees : Employee []= [
 {employeeId : 100,employeeName : 'John',employeeSalary : 800000},
 {employeeId : 400,employeeName : 'Martin',employeeSalary : 700000},
 {employeeId : 300,employeeName : 'Mojo',employeeSalary : 600000},

];
sortById()
{
  this.employees.sort((p1,p2)=> p1.employeeId - p2.employeeId);
}
sortByName()
{
  this.employees.sort((p1,p2)=> p1.employeeName .localeCompare (p2.employeeName));
}
sortBySalary()
{
  this.employees.sort((p1,p2)=> p1.employeeSalary - p2.employeeSalary);
}


sortById1()
{
  this.employees.sort((p1,p2)=> p2.employeeId - p1.employeeId);
}
sortByName1()
{
  this.employees.sort((p1,p2)=> p2.employeeName .localeCompare (p1.employeeName));
}

sortBySalary1()
{
  this.employees.sort((p1,p2)=> p2.employeeSalary - p1.employeeSalary);
}
add(eid,ename,esal)
{
  this.employees.push({employeeId : eid,employeeName : ename , employeeSalary : esal});
}
  constructor() { }

  ngOnInit() {
  }

}
