import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'power'
})
export class PowerPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let num : number = <number>args;
    return Math.pow(value,num);
  }

}
