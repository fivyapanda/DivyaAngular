import { Directive, ElementRef, Renderer, HostListener, HostBinding } from '@angular/core';

@Directive({
  selector: '[appChangecolor]'
})
export class ChangecolorDirective {
 @HostBinding('style.border') border : string;
 @HostBinding('style.background') background : string;

  constructor(private e1:ElementRef,private renderer: Renderer)
  
   { 
     this.renderer.setElementStyle(this.e1.nativeElement,'color','orange');
     
   }

    @HostListener('mouseover') onMouseOver()
   {
    this.renderer.setElementStyle(this.e1.nativeElement,'color','red');
    this.border = "2px solid gray";
    this.background="pink";
   }
   @HostListener('mouseout') onmouseout()
   {
    this.renderer.setElementStyle(this.e1.nativeElement,'color','black');
    this.border = "2px solid gray";
   }
}
