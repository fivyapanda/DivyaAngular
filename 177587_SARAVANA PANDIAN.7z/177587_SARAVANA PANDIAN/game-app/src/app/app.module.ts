import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { GameCityComponent } from './game-city/game-city.component';
import { Route,RouterModule } from '../../node_modules/@angular/router';
import { PlayComponent } from './play/play.component';
import { GamelistService } from './gamelist.service';
import {HttpClientModule} from '@angular/common/http';

const routes: Route []=[
  {
    path:"gamecity",
    component:GameCityComponent
   }, 
   {
    path:"play",
    component:PlayComponent,
   }, 
  ]

@NgModule({
  declarations: [
    AppComponent,
    GameCityComponent,
    PlayComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
  ],
  providers: [GamelistService],
  bootstrap: [AppComponent]
})
export class AppModule { }
