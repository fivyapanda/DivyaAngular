import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import {Igames} from './play/games'

@Injectable({
  providedIn: 'root'
})
export class GamelistService {
  url:string='assets/GameList.json';
  constructor(private http: HttpClient) { }

  getgames():Observable<Igames[]>{

    return this.http.get<Igames[]>(this.url);

  }
}
