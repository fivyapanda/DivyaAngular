import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-game-city',
  templateUrl: './game-city.component.html',
  styleUrls: ['./game-city.component.css']
})
export class GameCityComponent implements OnInit {
  balance:number;

  constructor() { }

  ngOnInit() {
  }
deduct(data:any){
  this.balance=data.amount-100;

}
}
