import { Component, OnInit } from '@angular/core';
import {Igames} from './games'
import { GamelistService } from '../gamelist.service';


@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  games:Igames[];
  gameid:number;
  gamename:string;
  gameprice:number;
 balance:number;

  constructor(private service :GamelistService) { }

  ngOnInit() {
   this.service.getgames().subscribe(play=>this.games=play)
  }

}
