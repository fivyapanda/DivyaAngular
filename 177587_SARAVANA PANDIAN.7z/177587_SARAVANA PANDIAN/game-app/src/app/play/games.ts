export interface Igames
{
    gameid:number;
    gamename:string;
    gameprice:number;
   
}