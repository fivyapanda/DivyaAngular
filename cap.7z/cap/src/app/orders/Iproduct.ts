export interface Iproduct{
    ProductId:number;
    ProductName:string;
    ProductQuantity:number;
    ProductPrice:number;

}
