import { Component, OnInit } from '@angular/core';
import { OrderServiceService } from '../order-service.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  constructor(private service:OrderServiceService) { }

  ngOnInit() {
    this.service.getproducts();
  }

  order(data:any){
    console.log(data);
     if(this.service.productList.find(x=>x.ProductId==data))
     {
       let product = this.service.productList.find(x=>x.ProductId==data);

      product.ProductQuantity += 1; 
      console.log(product);
     }
  }
}
