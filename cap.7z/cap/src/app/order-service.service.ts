import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Iproduct } from './orders/Iproduct';

@Injectable({
  providedIn: 'root'
})
export class OrderServiceService {
  url:string="assets/returnproduct.json";

  productList:Iproduct[];

  constructor(private http:HttpClient) { }
  getproducts():any{
    this.http.get<Iproduct[]>(this.url).subscribe(res=>{
      console.log(res);
      this.productList=res;
    })
  }
}
