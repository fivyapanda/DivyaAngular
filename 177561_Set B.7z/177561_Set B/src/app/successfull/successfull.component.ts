import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-successfull',
  templateUrl: './successfull.component.html',
  styleUrls: ['./successfull.component.css']
})
export class SuccessfullComponent implements OnInit {
gamount;
  constructor(private route:ActivatedRoute) { }

  ngOnInit() {
    let amount=this.route.snapshot.params['amount'];
    this.gamount=amount;
  }

}
