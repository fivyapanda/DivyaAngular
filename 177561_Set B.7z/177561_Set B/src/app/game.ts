export class IGame{
    gameId:number;
    gameName:string;
    gamePrice:number
}