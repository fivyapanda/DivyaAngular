import { Component, OnInit } from '@angular/core';
import { PlayService } from '../play.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { IGame } from '../game';

@Component({
  selector: 'app-play',
  templateUrl:'./play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
cardAmount:number;
isStart:boolean=false;
money:number;
game:IGame[];

  constructor(private service:PlayService) { }

  ngOnInit() {
  this.service.getGameList().subscribe(data=>this.game=data);
  }
onSubmit(data:any){
console.log(data);
this.isStart=true;
}
payment(g:IGame){
  if(this.cardAmount>g.gamePrice)
  {
  this.cardAmount=this.cardAmount-g.gamePrice;
  console.log(+g.gameName)
  alert("Thank you for playing "+g.gameName+"!"+"\n"+"Your Balance is Rs" +this.cardAmount);
  }
  else{
alert("Thank You for using our Online Gaming Site."+"\n"+"Insufficient Balance to play"+g.gameName+"\n"+"Please Topup Again!!!")
  }

}
}
