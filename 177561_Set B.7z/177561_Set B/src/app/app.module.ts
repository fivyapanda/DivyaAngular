import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import {RouterModule,Route} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { PlayComponent } from './play/play.component';
import { SuccessfullComponent } from './successfull/successfull.component';
const routes:Route[]=[
  {
    path:"game",
    component:PlayComponent
  },
  {
    path:'success/:amount',
    component:SuccessfullComponent
  },
  {
    path:'',
    redirectTo:'game',
    pathMatch:'full'
  },
]
@NgModule({
  declarations: [
    AppComponent,
    PlayComponent,
    SuccessfullComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
