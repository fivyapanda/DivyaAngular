import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { GameCityComponent } from './game-city/game-city.component';
import { Route ,RouterModule} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { PlayComponent } from './play/play.component';
const routes:Route[]=[
  {
    path:'GameCity',
    component:GameCityComponent
  },{
    path:'play',
    component:PlayComponent
  }];
@NgModule({
  declarations: [
    AppComponent,
    GameCityComponent,
    PlayComponent
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(routes),HttpClientModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
