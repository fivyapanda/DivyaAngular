import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IGame } from './game-city/game';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GameService {
  url:string="assets/GameList.json";
  constructor(private http:HttpClient) { }
  games():Observable<IGame[]>
  {
    return this.http.get<IGame[]>(this.url);
    
  }
}
