export interface IGame{
    gameId:number;
    gameName:String;
    gamePrice:number;
}