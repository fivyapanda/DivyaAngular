import { Component, OnInit } from '@angular/core';
import { IGame } from './game';
import { GameService } from '../game.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-game-city',
  templateUrl: './game-city.component.html',
  styleUrls: ['./game-city.component.css']
})
export class GameCityComponent implements OnInit {
game:IGame[];
userForm:FormGroup;
gameId:number;
gameName:String;
gamePrice:number;
  constructor(private service:GameService) { }
  ngOnInit() {
    this.userForm=new FormGroup({
      Name:new FormControl('',[Validators.required]),
      Address:new FormControl('',[Validators.required]),
      Amount:new FormControl(null,[Validators.required])
    });
  }

}
