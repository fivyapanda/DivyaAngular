import { Component, OnInit } from '@angular/core';
import { IGame } from '../game-city/game';
import { GameService } from '../game.service';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  game:IGame[];
  Amount:number=1000;
Price:number;
serviceCharge:number=100;
  constructor(private service:GameService) { }

  ngOnInit() {
    this.service.games().subscribe(data=>this.game=data);
  }
  play(game:IGame){
    this.Price=game.gamePrice+this.serviceCharge;
    if(this.Amount>game.gamePrice){
      this.Amount=this.Amount-this.Price;
      alert("your Balance is:"+this.Amount);
    }
    else{
      alert("Insufficient Amount");
    }
}
}